//
//  UserData+CoreDataClass.swift
//  kumaraguruCRUD
//
//  Created by developer on 17/02/24.
//
//

import Foundation
import CoreData

@objc(UserDatas)
public class UserDatas: NSManagedObject {

}
