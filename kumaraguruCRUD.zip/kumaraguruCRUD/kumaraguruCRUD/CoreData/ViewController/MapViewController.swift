//
//  MapViewController.swift
//  kumaraguruCRUD
//
//  Created by developer on 16/02/24.
//

import UIKit
import MapKit
import CoreLocation

class MapViewController: UIViewController ,CLLocationManagerDelegate{

    @IBOutlet weak var bgView: UIView!
    @IBOutlet weak var titleView: UIView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var backButton: UIButton!
    
    @IBOutlet weak var detailsView: UIView!
    @IBOutlet weak var latLabel: UILabel!
    @IBOutlet weak var longLabel: UILabel!
    
    @IBOutlet weak var mapBgView: UIView!
    @IBOutlet weak var mapView: MKMapView!
    
    
    let manager = CLLocationManager()
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setupUI()
       
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        self.navigationController?.setNavigationBarHidden(true, animated: true)
        self.setupMapview()
       
    }
    

    @IBAction func didBackBtnTapped(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    

}
extension MapViewController {
    
    func setupUI(){
        if #available(iOS 13.0, *) {
            self.view.backgroundColor = UIColor.systemGray6
        } else {
            self.view.backgroundColor = UIColor.lightGray
        }
        self.bgView.backgroundColor = .clear
        self.titleView.backgroundColor = .clear
        self.titleLabel.setLabelWithTitle(titleColor: .black, title: "Map View", font: .boldSystemFont(ofSize: 20),alignment: .center)
        self.detailsView.backgroundColor = .white
        self.detailsView.layer.cornerRadius = 20
        self.detailsView.layer.borderColor = UIColor.blue.cgColor
        self.detailsView.layer.borderWidth = 2
        
        self.mapBgView.backgroundColor = .clear
        
    }
    
    func setValues(lat:String,long:String,area:String){
        self.latLabel.setLabelWithTitle(titleColor: .black, title: "Current Latitude : \(lat)", font: .boldSystemFont(ofSize: 16), alignment: .left)
        self.longLabel.setLabelWithTitle(titleColor: .black, title: "Current Longitude : \(long)", font: .boldSystemFont(ofSize: 16), alignment: .left)
    }
    
    func setupMapview(){
        self.manager.desiredAccuracy = kCLLocationAccuracyBest
        self.manager.requestWhenInUseAuthorization()
        self.manager.delegate = self
        self.manager.startUpdatingLocation()
    }
}
extension MapViewController {
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let location = locations.first{
            manager.stopUpdatingLocation()
            let latitue = "\(location.coordinate.latitude)"
            let longitude = "\(location.coordinate.longitude)"
            self.setValues(lat: latitue, long: longitude, area: "")
            self.render(location:location)
        }
    }
    
    func render(location: CLLocation){
        let coordinates = CLLocationCoordinate2D(latitude: location.coordinate.latitude, longitude: location.coordinate.longitude)
        
        let span = MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1)
        
        let region = MKCoordinateRegion(center: coordinates, span: span)
        
        self.mapView.setRegion(region, animated: true)
        
        let pin = MKPointAnnotation()
        pin.coordinate = coordinates
        self.mapView.addAnnotation(pin)
    }
}
