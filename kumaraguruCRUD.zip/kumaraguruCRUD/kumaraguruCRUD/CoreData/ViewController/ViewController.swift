//
//  ViewController.swift
//  kumaraguruCRUD
//
//  Created by developer on 16/02/24.
//

import UIKit

class ViewController: UIViewController {
 
    @IBOutlet weak var bgView: UIView!
    
    @IBOutlet weak var titleView: UIView!
    @IBOutlet weak var titleLabel: UILabel!
    
    @IBOutlet weak var nameView: UIView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var nameTextField: UITextField!
    
    @IBOutlet weak var emailView: UIView!
    @IBOutlet weak var emailLabel: UILabel!
    @IBOutlet weak var emailTextField: UITextField!
    
    @IBOutlet weak var mobileView: UIView!
    @IBOutlet weak var mobileLabel: UILabel!
    @IBOutlet weak var mobileTextField: UITextField!
    
    @IBOutlet weak var genderView: UIView!
    @IBOutlet weak var genderLabel: UILabel!
    @IBOutlet weak var genderTextField: UITextField!

    @IBOutlet weak var bottomView: UIView!
    @IBOutlet weak var createButton: UIButton!
    @IBOutlet weak var editButton: UIButton!
    @IBOutlet weak var mapButton: UIButton!
    
    let apiUrlString = "https://crudcrud.com/api/d4f8e777d61d4e24a926cfa2ad34ee8b/kumaraguru"
    var isEdit = false
    var userId: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setupUI()
        self.setDataDB()
    }

    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    
    @IBAction func didCreateBtnTapped(_ sender: Any) {
        self.isEdit = false
        self.createDataAction()
    }
    
    @IBAction func didEditBtnTapped(_ sender: Any) {
        self.isEdit = true
        self.createDataAction()
    }
    
    @IBAction func didMapBtnTapped(_ sender: Any) {
        guard let vc = self.storyboard?.instantiateViewController(withIdentifier: "MapViewController") as? MapViewController else{
            return
        }
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    
}
extension ViewController {
    
    func setupUI(){
        if #available(iOS 13.0, *) {
            self.view.backgroundColor = UIColor.systemGray6
        } else {
            self.view.backgroundColor = UIColor.lightGray
        }
        self.bgView.backgroundColor = .clear
        self.titleView.backgroundColor = .clear
        self.titleLabel.setLabelWithTitle(titleColor: .black, title: "CoreData", font: .boldSystemFont(ofSize: 20),alignment: .center)
        
        self.setViews(View: self.nameView, Label: self.nameLabel, Textfield: self.nameTextField,LabelString: "Name:",Placeholder: "Enter Name")
        
        self.setViews(View: self.emailView, Label: self.emailLabel, Textfield: self.emailTextField,LabelString: "Email:",Placeholder: "Enter Email")
        
        self.setViews(View: self.mobileView, Label: self.mobileLabel, Textfield: self.mobileTextField,LabelString: "Mobile:",Placeholder: "Enter Mobile")
        
        self.setViews(View: self.genderView, Label: self.genderLabel, Textfield: self.genderTextField,LabelString: "Gender:",Placeholder: "Enter Gender")
        
        self.bottomView.backgroundColor = .clear
        self.createButton.setButton(titleColor: .green, backgroundColor: .white, cornerRadius: 16, borderColor: .green, borderWidth: 2, title: "Create", fontSize: .boldSystemFont(ofSize: 16), shadowColor: UIColor.green.cgColor, shadowRadius: 5.0, shadowOpacity: 0.5)
        
        self.editButton.setButton(titleColor: .systemBlue, backgroundColor: .white, cornerRadius: 16, borderColor: .systemBlue, borderWidth: 2, title: "Edit", fontSize: .boldSystemFont(ofSize: 16), shadowColor: UIColor.systemBlue.cgColor, shadowRadius: 5.0, shadowOpacity: 0.5)
        
        self.mapButton.setButton(titleColor: .yellow, backgroundColor: .black, cornerRadius: 16, borderColor: .yellow, borderWidth: 2, title: "Goto Map", fontSize: .boldSystemFont(ofSize: 16), shadowColor: UIColor.yellow.cgColor, shadowRadius: 5.0, shadowOpacity: 0.5)
    }
    
    func setDataDB(){
        let retrievedData = DataManager.shared.retrieveData()
        if retrievedData == nil{
            self.editButton.isHidden = true
            self.createButton.isHidden = false
        }else{
            self.setTextFieldValues(name: retrievedData?.name ?? "", email: retrievedData?.email ?? "", mobile: retrievedData?.mobile ?? "", gender: retrievedData?.gender ?? "")
            self.editButton.isHidden = false
            self.createButton.isHidden = true
        }
             
    }
    
    func setViews(View:UIView,Label:UILabel,Textfield:UITextField,LabelString:String,Placeholder:String){
        
        View.backgroundColor = .clear
        Label.setLabelWithTitle(titleColor: .darkGray, title: LabelString, font: .boldSystemFont(ofSize: 16), alignment: .left)
        Textfield.setupTextField(placeHolder: Placeholder, textColor: .black, font: .boldSystemFont(ofSize: 18), alignment: .left)
        Textfield.delegate = self
    }
    
    func setTextFieldValues(name:String,email:String,mobile:String,gender:String){
        
        self.nameTextField.text = name
        self.emailTextField.text = email
        self.mobileTextField.text = mobile
        self.genderTextField.text = gender
    }
}
extension ViewController : UITextFieldDelegate{
    
}
extension ViewController {
    
    func createDataAction(){
        let nameTxt = self.nameTextField.text ?? ""
        let emailTxt = self.emailTextField.text ?? ""
        let mobileTxt = self.mobileTextField.text ?? ""
        let genderTxt = self.genderTextField.text ?? ""
        
        if nameTxt == ""{
            self.nameTextField.becomeFirstResponder()
            self.showTemporaryAlert(title: "Oops!!",message: "Please Enter Name!", duration: 2.0)
            return
        }
        if emailTxt == ""{
            self.emailTextField.becomeFirstResponder()
            self.showTemporaryAlert(title: "Oops!!",message: "Please Enter Email!", duration: 2.0)
            return
        }
        if mobileTxt == ""{
            self.mobileTextField.becomeFirstResponder()
            self.showTemporaryAlert(title: "Oops!!",message: "Please Enter Mobile!", duration: 2.0)
            return
        }
        if genderTxt == ""{
            self.genderTextField.becomeFirstResponder()
            self.showTemporaryAlert(title: "Oops!!",message: "Please Enter Gender!", duration: 2.0)
            return
        }
        let result = userModel(id: self.userId,name: nameTxt, mobile: mobileTxt, email: emailTxt, gender: genderTxt)
        if self.isEdit {
            DataManager.shared.update(data: result)
            self.showTemporaryAlert(title: "Updated", message: "Data Updated Successfully", duration: 2)
            self.setDataDB()
        }else {
            self.createData(result)
        }
    }
    
    func showTemporaryAlert(title: String,message: String, duration: Double) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        present(alert, animated: true, completion: nil)
        
        DispatchQueue.main.asyncAfter(deadline: .now() + duration) {
            alert.dismiss(animated: true, completion: nil)
        }
    }
}

extension ViewController {
    
    func createData(_ data: userModel) {
        DataManager.shared.postDataToApi(data: data) { [self] in
            fetchData()
        }
    }
    
    func fetchData() {
        DataManager.shared.getResponseFromApi { [self] id in
            userId = id
            showTemporaryAlert(title: "Success",message: "Data Created Successfully", duration: 2)
            setDataDB()
        }
    }
}
