//
//  model.swift
//  kumaraguruCRUD
//
//  Created by Netcom on 17/02/24.
//

import Foundation

struct userModel {
    var id : String?
    var name: String?
    var mobile: String?
    var email: String?
    var gender: String?
}
