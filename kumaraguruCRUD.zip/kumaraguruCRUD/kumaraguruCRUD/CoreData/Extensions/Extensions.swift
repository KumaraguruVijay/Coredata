//
//  Extensions.swift
//  kumaraguruCRUD
//
//  Created by developer on 16/02/24.
//

import Foundation
import UIKit
extension UILabel {
    func setLabelWithTitle(titleColor: UIColor, title: String,font: UIFont,alignment: NSTextAlignment) {
        self.text = title
        self.textColor = titleColor
        self.font = font
        self.textAlignment = alignment
        self.numberOfLines = 0
    }
}
extension UITextField{
    func setupTextField(placeHolder: String,textColor: UIColor, font: UIFont,alignment: NSTextAlignment) {
        self.autocorrectionType = .no
        self.spellCheckingType = .no
        self.autocapitalizationType = .words
        self.placeholder = placeHolder
        self.textColor = textColor
        self.font = font
        self.textAlignment = alignment
        self.borderStyle = .none
        self.addDoneButtonOnKeyboard()
    }
    func addDoneButtonOnKeyboard(){
        let doneToolbar: UIToolbar = UIToolbar()
        doneToolbar.barStyle = .blackTranslucent
        
        let flexSpace = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        
        let done = UIBarButtonItem(title: "Done", style: .done, target: self, action: #selector(UITextField.doneButtonAction))
        done.tintColor = .black// Set the text color of the "Done" button to blue
        let font = UIFont.boldSystemFont(ofSize: 18) // Change the font size as needed
        let attributes: [NSAttributedString.Key: Any] = [NSAttributedString.Key.font: font]
        done.setTitleTextAttributes(attributes, for: .normal)
        
        let items: [UIBarButtonItem] = [flexSpace, done]
        
        doneToolbar.setItems(items, animated: false)
        //doneToolbar.backgroundColor = .lightGray
        doneToolbar.barTintColor = .gray
        doneToolbar.sizeToFit()
        
        self.inputAccessoryView = doneToolbar
    }
    @objc func doneButtonAction(){
        self.resignFirstResponder()
    }
}
extension UIButton{
    func setButton(titleColor: UIColor, backgroundColor: UIColor, cornerRadius: CGFloat,borderColor: UIColor,borderWidth: CGFloat,title: String,fontSize: UIFont,shadowColor: CGColor, shadowRadius: CGFloat, shadowOpacity: Float) {
        if #available(iOS 15.0, *) {
            self.configuration = .none
        }
        self.setTitle(title, for: .normal)
        self.setTitleColor(titleColor, for: .normal)
        self.backgroundColor = backgroundColor
        self.layer.cornerRadius = cornerRadius
        self.layer.borderColor = borderColor.cgColor
        self.layer.borderWidth = borderWidth
        self.titleLabel?.font = fontSize
        self.layer.shadowColor = shadowColor
        self.layer.shadowOffset = CGSize(width: 0, height: 3)
        self.layer.shadowOpacity = shadowOpacity
        self.layer.shadowRadius = shadowRadius
    }
}
