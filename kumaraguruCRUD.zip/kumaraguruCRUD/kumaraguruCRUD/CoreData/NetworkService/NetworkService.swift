//
//  NetworkService.swift
//  kumaraguruCRUD
//
//  Created by developer on 17/02/24.
//

import Foundation

protocol ApiService {
    var apiUrl: String? { get }
    func getMethod(onCompletion: @escaping(_ data: userModel, _ error: String) -> Void)
    func postMethod(userDetails: userModel, onCompletion: @escaping() -> Void)
}

class NetworkService: NSObject, ApiService {
    
    var apiUrl: String? = "https://crudcrud.com/api/d4f8e777d61d4e24a926cfa2ad34ee8b/kumaraguru"
    
    func postMethod(userDetails: userModel, onCompletion: @escaping () -> Void) {
        guard let url = URL(string: apiUrl ?? "") else {
            print("Invalid URL")
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")

        let data: [String: Any] = [
            "name": userDetails.name,
            "email": userDetails.email,
            "mobile": userDetails.mobile,
            "gender": userDetails.gender
        ] as! [String: Any]

        do {
            request.httpBody = try JSONSerialization.data(withJSONObject: data)
        } catch {
            print("Error encoding data: \(error.localizedDescription)")
            return
        }

        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Error creating data: \(error.localizedDescription)")
            } else if let data = data {
                print("Data created successfully: \(String(data: data, encoding: .utf8) ?? "")")
                onCompletion()
            }
        }.resume()
    }

    func getMethod(onCompletion: @escaping(_ data: userModel, _ error: String) -> Void) {
   
        guard let url = URL(string: apiUrl ?? "") else { return }
   
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Error fetching data: \(error.localizedDescription)")
            } else if let data = data {
                do {
                    if let jsonData = try JSONSerialization.jsonObject(with: data, options: []) as? [[String: Any]] {
                        print("jsonData:",jsonData)
                        DispatchQueue.main.async {
                            
                            if let dict = jsonData.last {
                                let id = "\(dict["_id"] ?? "")"
                                let name = "\(dict["name"] ?? "")"
                                let email = "\(dict["email"] ?? "")"
                                let mobile = "\(dict["mobile"] ?? "")"
                                let gender = "\(dict["gender"] ?? "")"
                                print("Retrieved data - Id:\(id), Name: \(name), Email: \(email), Mobile: \(mobile), Gender: \(gender)")
                                let result = userModel(id: id,name: name, mobile: mobile, email: email, gender: gender)
                                onCompletion(result, "")
                            }
                        }
                    }
                } catch {
                    print("Error decoding data: \(error.localizedDescription)")
                }
            }
        }.resume()
    }
}
