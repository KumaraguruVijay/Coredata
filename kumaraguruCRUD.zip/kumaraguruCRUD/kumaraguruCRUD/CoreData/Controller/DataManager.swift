//
//  DataManager.swift
//  kumaraguruCRUD
//
//  Created by developer on 16/02/24.
//

import Foundation
import CoreData
import UIKit


class DataManager {
    
    static let shared = DataManager()
    
    var userList: [UserData] = []
    var apiService: NetworkService = NetworkService()
    
    func retrieveData() -> userModel? {
        let appdelegate = UIApplication.shared.delegate as? AppDelegate
        
        let container = appdelegate?.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "UserData")
        
        do {
            guard let result = try container?.fetch(fetchRequest) else { return nil }
            if !result.isEmpty {
                let retrieveValue = result.last as! NSManagedObject
                return userModel(name: retrieveValue.value(forKey: "name") as? String,mobile: retrieveValue.value(forKey: "mobile") as? String, email: retrieveValue.value(forKey: "email") as? String,gender: retrieveValue.value(forKey: "gender") as? String)
            }else {
                return nil
            }
           /*for data in result as! [NSManagedObject] {
                print(data.value(forKey: "name") as! String)
                
            }*/
        } catch {
            
            print("Failed")
        }
        return nil
    }

    func insertData(data: userModel) {
        guard let appdelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        
        let container = appdelegate.persistentContainer.viewContext
        
        let userList = UserData(context: container)
        
        userList.id = data.id
        userList.name = data.name
        userList.email = data.email
        userList.mobile = data.mobile
        userList.gender = data.gender
        
        appdelegate.saveContext()
    }
    func update(data: userModel) {
        guard let appdelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let container = appdelegate.persistentContainer.viewContext
        
        let fetchRequest:NSFetchRequest<NSFetchRequestResult> = NSFetchRequest.init(entityName: "UserData")
        fetchRequest.predicate = NSPredicate(format: "id = %@", "\(data.id ?? "")")
        do
        {
            let test = try container.fetch(fetchRequest)
            if !test.isEmpty {
                let objectUpdate = test.last as! NSManagedObject
                objectUpdate.setValue(data.name, forKey: "name")
                objectUpdate.setValue(data.email, forKey: "email")
                objectUpdate.setValue(data.mobile, forKey: "mobile")
                objectUpdate.setValue(data.gender, forKey: "gender")
                do{
                    try container.save()
                }
                catch
                {
                    print(error)
                }
            }
            
        }
        catch
        {
            print(error)
        }
    }
    
}
extension DataManager {
    
    func getResponseFromApi(onCompletion: @escaping(_ userData: String) -> Void ) {
        apiService.getMethod { [self] data, error in
            insertData(data: data)
            onCompletion(data.id ?? "")
        }
    }
    
    func postDataToApi(data: userModel, onCompletion: @escaping() -> Void) {
        apiService.postMethod(userDetails: data) {
            onCompletion()
        }
    }
}
